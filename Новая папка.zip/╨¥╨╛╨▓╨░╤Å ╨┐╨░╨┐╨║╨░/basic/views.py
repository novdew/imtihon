from django.shortcuts import render, get_object_or_404
from .models import *
from django.views import generic


# Create your views here.
class HomeView(generic.ListView):
    model = Product
    template_name = 'basic/home.html'
    context_object_name = 'products'


class DetailView(generic.DetailView):
    model = Product
    template_name = 'basic/detail.html'
    context_object_name = 'product'


# function based views
def categoryView(request, category_slug):
    categories = Category.objects.all()
    category = Category.objects.get(slug=category_slug)
    products = Product.objects.filter(category=category)
    return render(request, 'basic/by_category.html', {'category': category,
                                                      'categories': categories,
                                                      'products': products})
