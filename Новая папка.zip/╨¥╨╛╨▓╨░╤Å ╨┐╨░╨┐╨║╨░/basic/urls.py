from django.urls import path
from . import views

urlpatterns = [
    path('', views.HomeView.as_view(), name='home'),
    path('<slug:slug>/', views.categoryView, name='category_view'),
    path('<int:pk>/', views.DetailView.as_view(), name='detail'),
]
